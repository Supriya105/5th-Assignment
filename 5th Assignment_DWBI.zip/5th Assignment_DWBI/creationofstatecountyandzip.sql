use [Assignment]

--Table state
CREATE TABLE [State]
(
 [SPK] Int IDENTITY ,
 [Stateabbreviation] Nvarchar(10) NOT NULL,
 [Statename] Nvarchar(50) ,
 [StateFIPS] Nvarchar(50) 
)
go
ALTER TABLE [State] ADD CONSTRAINT [Key1] PRIMARY KEY ([StateAbbreviation])
go

--Table County
CREATE TABLE [County]
(
 [SPK] Int IDENTITY ,
 [CountyName] Nvarchar(50) ,
 [FIPS] Nvarchar(50) ,
 [Stateabbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [County] ADD CONSTRAINT [Key2] PRIMARY KEY ([StateAbbreviation])
go

--Table Zip
CREATE TABLE [Zip]
(
 [SPK] Int IDENTITY ,
 [Zip] Nvarchar(50) ,
 [town] Nvarchar(50) ,
 [Stateabbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [Zip] ADD CONSTRAINT [Key3] PRIMARY KEY ([StateAbbreviation])
go